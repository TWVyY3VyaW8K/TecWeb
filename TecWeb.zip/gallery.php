<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <meta http-equiv="Content-Type" content="application/xhtml; charset=UTF-8"/>
    <meta name="description" content="Online artwork database"/>
    <meta name="keywords" content="artwork,picture,image,database"/>
    <meta name="author" content="Daniele Bianchin, Pardeep Singh, Davide Liu, Harwinder Singh"/>
    <meta name="title" content="Gallery - Artbit"/>
    <meta name="language" content="english en"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1"/>
    <link rel="stylesheet" type="text/css" href="Style/style.css" media="all"/>
    <link rel="stylesheet" type="text/css" href="Style/print.css" media="print" />
    <script type="text/javascript" src="script.js" ></script>
    <link rel="icon" type="image/png" href="Images/logo.png"/>
    <title>Gallery - Artbit</title>
</head>

<body onload="scrollFunction(); scrollToImage();" >
    <?php
        require_once "header.php";
        require_once "DbConnector.php";
        require_once "functions.php";
        $pagNumber = galleryPagNumberFromUrl();
        saveBackPage();
        if(isset($_GET['lNumI'])){
            galleryImageNumberFromUrl();
        }
    ?>
    <div class="gallery container1024" id="content">
        <form method="get" action="" name="formArtFilter">
            <div class="artFilter">
                <div class="inputSearch">
                    <?php
                        if(isset($_GET['gallerySearch'])){
                            $gallerySearch = htmlspecialchars($_GET["gallerySearch"], ENT_QUOTES, "UTF-8");//cleaning the input
                            echo '<label for="searchField">Search for category, artist, description ..</label>';
                            echo '<input id="searchField" type="text" name="gallerySearch" value="'.$gallerySearch.'"/>';
                            resetSessionPaginationNum('pagNum'.ucfirst(pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME)));
                        }else{
                        	echo '<label for="searchField">Search for category, artist, description ..</label>';
                            echo '<input id="searchField" type="text" name="gallerySearch"/>';
                        }

                    ?>
                    <button class="btnSearch" type="submit" onclick="deleteCookie('divPagNumber')"><span class="searchIcon"></span></button>
                </div>
                <div class="divCategoryFilter">
                    <p>Categories</p>

                    <?php
                        if(!isset($_SESSION['galleryCategory'])){
                            $_SESSION['galleryCategory'] = $galleryCategory = 'All';
                        }
                        if(!isset($_GET['galleryCategory'])){
                            $galleryCategory= $_SESSION['galleryCategory'];
                        }else{
                            resetSessionPaginationNum('pagNum'.ucfirst(pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME)));
                            $galleryCategory = htmlspecialchars($_GET["galleryCategory"], ENT_QUOTES, "UTF-8");//cleaning the input
                            $_SESSION['galleryCategory'] = $galleryCategory;
                        }
                    ?>
                    <div class="div-center">
                        <div class="divCategoryButtons">
                            <button type="submit" name="galleryCategory" value="All" <?php if(isset($galleryCategory) && $galleryCategory=='All'){echo "class='active'";} ?>>All</button>
                            <button type="submit" name="galleryCategory" value="Landscape" <?php if(isset($galleryCategory) && $galleryCategory=='Landscape'){echo "class='active'";} ?>>Landscape</button>
                            <button type="submit" name="galleryCategory" value="Fantasy"<?php if(isset($galleryCategory) && $galleryCategory=='Fantasy'){echo "class='active'";} ?>>Fantasy</button>
                            <button type="submit" name="galleryCategory" value="Abstract" <?php if(isset($galleryCategory) && $galleryCategory=='Abstract'){echo "class='active'";} ?>>Abstract</button>
                            <button type="submit" name="galleryCategory" value="Cartoon" <?php if(isset($galleryCategory) && $galleryCategory=='Cartoon'){echo "class='active'";} ?>>Cartoon</button>
                            <button type="submit" name="galleryCategory" value="Portrait" <?php if(isset($galleryCategory) && $galleryCategory=='Portrait'){echo "class='active'";} ?>>Portrait</button>
                            <button type="submit" name="galleryCategory" value="Nature" <?php if(isset($galleryCategory) && $galleryCategory=='Nature'){echo "class='active'";} ?>>Nature</button>
                            <button type="submit" name="galleryCategory" value="Others" <?php if(isset($galleryCategory) && $galleryCategory=='Others'){echo "class='active'";} ?>>Others</button>
                        </div>
                    </div>
                    <label for="orderBy">Order By:</label>
                    <select id="orderBy" name="orderBy" onchange='this.form.submit()'>
                      <option value="none"> --- </option>
                      <option value="likes" <?php if(isset($_GET['orderBy']) && $_GET['orderBy']=='likes'){echo "selected='selected'";} ?>>Likes</option>
                      <option value="latestAdded" <?php if((isset($_GET['orderBy']) && $_GET['orderBy']=='latestAdded') || (!isset($_GET['orderBy']))){echo "selected='selected'"; $_GET['orderBy'] = 'latestAdded';} ?>>Latest Added</option>
                    </select>
                </div>

            </div>
        </form>

        <?php $mostraPagination=FALSE; $j=0;?>
        <div class="clearfix galleryBoard">
            <?php
                $result;
                $orderBy = isset($_GET['orderBy']) ? $_GET['orderBy'] : 'none';
                $mostraPagination;
                if(isset($gallerySearch)){
                    //connecting to db
                    $myDb= new DbConnector();
                    $myDb->openDBConnection();
                    $result = array();
                    if($myDb->connected){
                        if(!isset($galleryCategory) || (isset($galleryCategory) && ($galleryCategory == 'All'))){
                            $qrStr = "SELECT Artista,Nome FROM opere WHERE Descrizione LIKE '%".$gallerySearch."%' OR Categoria LIKE '%".$gallerySearch."%' OR Artista LIKE '%".strtolower($gallerySearch)."%' OR Nome LIKE '%".$gallerySearch."%'";
                            if($orderBy == 'likes'){
                            	$qrStr = "SELECT Nome, Artista, COUNT(likes.Opera) as Likes FROM opere o LEFT JOIN likes on Nome=Opera and Artista=Creatore
                                    WHERE o.Descrizione LIKE '%".$gallerySearch."%' OR o.Categoria LIKE '%".$gallerySearch."%' OR o.Artista LIKE '%".$gallerySearch."%' OR Nome LIKE '%".$gallerySearch."%'
                                    GROUP BY o.Nome, o.Artista ORDER BY COUNT(likes.Opera) DESC";
                            }
                            if($orderBy == 'latestAdded'){
                            	$qrStr = "SELECT Artista,Nome FROM opere WHERE Descrizione LIKE '%".$gallerySearch."%' OR Categoria LIKE '%".$gallerySearch."%' OR Artista LIKE '%".strtolower($gallerySearch)."%' OR Nome LIKE '%".$gallerySearch."%' ORDER BY Data_upload DESC";
                            }
                        }elseif(isset($galleryCategory) && ($galleryCategory != 'All')){
                            $qrStr = 'SELECT Artista,Nome FROM opere WHERE Categoria="'.$galleryCategory.'" AND (Descrizione LIKE "%'.$gallerySearch.'%" OR Artista LIKE "%'.strtolower($gallerySearch).'%" OR Nome LIKE "%'.$gallerySearch.'%")';
                            if($orderBy == 'likes'){
                            	$qrStr = 'SELECT Nome, Artista, COUNT(likes.Opera) as Likes FROM opere LEFT JOIN likes on Nome=Opera and Artista=Creatore
                                     WHERE Categoria="'.$galleryCategory.'" AND (Descrizione LIKE "%'.$gallerySearch.'%" OR Artista LIKE "%'.$gallerySearch.'%" OR Nome LIKE "%'.$gallerySearch.'%")
                                     GROUP BY Nome, Artista ORDER BY COUNT(likes.Opera) DESC';
                            }
                            if($orderBy == 'latestAdded'){
                                $qrStr = 'SELECT Artista,Nome FROM opere WHERE Categoria="'.$galleryCategory.'" AND (Descrizione LIKE "%'.$gallerySearch.'%" OR Artista LIKE "%'.strtolower($gallerySearch).'%" OR Nome LIKE "%'.$gallerySearch.'%") ORDER BY Data_upload DESC';
                            }
                        }
                        $result = $myDb->doQuery($qrStr);
                    }
                    else
                        echo "<div class='div-center'><p>Errore connessione</p></div>";
                    $myDb->disconnect();
                }elseif(isset($galleryCategory)){
                    //connecting to db
                    $myDb= new DbConnector();
                    $myDb->openDBConnection();
                    $result = array();
                    if($myDb->connected){
                        if($galleryCategory == 'All'){
                            $qrStr = "SELECT Artista,Nome FROM opere;";
                            if($orderBy == 'likes'){
                                $qrStr = "SELECT Nome, Artista, COUNT(likes.Opera) as Likes FROM opere LEFT JOIN likes on Nome=Opera and Artista=Creatore GROUP BY Nome, Artista ORDER BY COUNT(likes.Opera) DESC";
                            }
                            if($orderBy == 'latestAdded'){
                                $qrStr = "SELECT Artista,Nome FROM opere ORDER BY Data_upload DESC;";
                            }
                        }else{
                            $qrStr = "SELECT Artista,Nome FROM opere WHERE Categoria='".$galleryCategory."'";
                            if($orderBy == 'likes'){
                                $qrStr = "SELECT Nome, Artista, COUNT(likes.Opera) as Likes FROM opere JOIN likes on Nome=Opera and Artista=Creatore
                                     WHERE Categoria='".$galleryCategory."' GROUP BY Nome, Artista ORDER BY COUNT(likes.Opera) DESC";
                            }
                            if($orderBy == 'latestAdded'){
                                $qrStr = "SELECT Artista,Nome FROM opere WHERE Categoria='".$galleryCategory."' ORDER BY Data_upload DESC;";
                            }
                        }

                        $result = $myDb->doQuery($qrStr);
                    }
                    else
                        echo "<div class='div-center'><p>Errore connessione</p></div>";
                    $myDb->disconnect();
                }
                if($result && ($result->num_rows > 0)){
                    $mostraPagination = ($result->num_rows > $GLOBALS['imagesPerPage']) ? true : false;
                    $j = printGalleryItems($result,FALSE,$_SESSION['pagNum'.ucfirst(pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME))]);
                }elseif(!$result || ($result->num_rows == 0)){
                    echo "<div class='div-center'><p>Nothing to show here ... </p></div>";
                }
            ?>
        </div>
        <?php
            printPagination($mostraPagination,$j,$_SESSION['pagNum'.ucfirst(pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME))],basename($_SERVER['PHP_SELF']));
        ?>
    </div>
	<?php require_once "footer.html";?>
</body>
</html>
